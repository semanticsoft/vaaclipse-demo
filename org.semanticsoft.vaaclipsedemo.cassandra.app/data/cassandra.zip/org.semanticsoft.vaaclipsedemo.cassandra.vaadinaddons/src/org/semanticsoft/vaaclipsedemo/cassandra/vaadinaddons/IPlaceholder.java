package org.semanticsoft.vaaclipsedemo.cassandra.vaadinaddons;

public interface IPlaceholder
{

}
